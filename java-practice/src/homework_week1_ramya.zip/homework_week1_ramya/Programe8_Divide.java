package homework_week1_ramya;

public class Programe8_Divide {
    public static void main(String[] args){
        System.out.println("Test Data: 50/3");
        System.out.println("Expected Output: 16");
    }
}
