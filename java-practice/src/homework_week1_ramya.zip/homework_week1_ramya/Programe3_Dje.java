package homework_week1_ramya;

public class Programe3_Dje {
public static void main(String[] args){
    System.out.println("******");
    System.out.println("**  **");
    System.out.println("**   **");
    System.out.println("**   **");
    System.out.println("**   **");
    System.out.println("**   **");
    System.out.println("**   **");
    System.out.println("**  **");
    System.out.println("*****");






}




}
