package homework_week1_ramya;

public class Programe10_Input {
    public static void main(String[] args){
        System.out.println("Test Data:");
        System.out.println("Input first number: 25");
        System.out.println("Input second number: 5");
        System.out.println("Expected Output : 25 x 5 = 125");
    }
}
