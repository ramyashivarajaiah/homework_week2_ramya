package homework_week1_ramya;

public class Programe1_Biodata {
    public static void main(String[] args) {
        System.out.println("Biodata");
        System.out.println("Name: Sherlock Holmes");
        System.out.println("Father's Name : Siger Holmes");
        System.out.println("Mother's Name : Violet Rutherford");
        System.out.println("DOB : 06/01/1954");
        System.out.println("Adress : 221B Bakers Street");
        System.out.println("London");
        System.out.println("NW1 6XE");
        System.out.println("Contact Number: 020 7224 3688");
        System.out.println("Hobbies: Music,Boxing, Travelling");
        System.out.println("Qualification : chemistry");




    }





}
