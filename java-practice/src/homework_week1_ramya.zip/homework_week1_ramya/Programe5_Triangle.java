package homework_week1_ramya;

public class Programe5_Triangle {
    public static void main(String[] args){
    System.out.println("     *");
    System.out.println("    * *");
    System.out.println("   * * *");
    System.out.println("  * * * *");
    System.out.println(" * * * * *");
    System.out.println("* * * * * *");


    }

}
