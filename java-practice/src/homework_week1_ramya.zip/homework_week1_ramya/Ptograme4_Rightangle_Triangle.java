package homework_week1_ramya;

public class Ptograme4_Rightangle_Triangle {
    public static void main(String[] args){
    System.out.println("*");
    System.out.println("**");
    System.out.println("***");
    System.out.println("****");
    System.out.println("*****");
    System.out.println("******");


    }

}
